import {
  armorClass,
  ITEMS,
  mod,
  NPCS,
  STAT_FULL,
  STAT_GEN,
  who,
} from "./content";
import type { Hero, NpcId, RollView, Save, StatKey } from "./types";

export { armorClass, mod, STAT_FULL };

export function signed(n: number): string {
  return n >= 0 ? `+${n}` : `−${Math.abs(n)}`;
}

export function fill(text: string, save: Save): string {
  const hero = save.hero;
  if (!hero) return text;
  return text
    .replaceAll("{{name}}", hero.name)
    .replaceAll("{{who}}", who(hero));
}

export function formatRoll(roll: RollView): string {
  const dice = roll.d20b != null ? `${roll.d20}/${roll.d20b}` : `${roll.d20}`;
  const sign = roll.mod >= 0 ? `+ ${roll.mod}` : `− ${Math.abs(roll.mod)}`;
  let result = roll.success ? "Успех" : "Провал";
  if (roll.crit) result = "Критический успех";
  else if (roll.fumble) result = "Критический промах";
  let line = `[${roll.label}: d20(${dice}) ${sign} = ${roll.total} vs КС ${roll.dc} — ${result}!]`;
  if (roll.grit) line += " Упрямство человека перебрасывает кость.";
  return line;
}

export function relLabel(n: number): string {
  if (n <= -60) return "Враг";
  if (n <= -20) return "Неприязнь";
  if (n < 20) return "Настороженность";
  if (n < 45) return "Доверие";
  if (n < 70) return "Близость";
  return "Преданность";
}

export function partyLine(save: Save): string {
  const ids = (Object.keys(save.npcs) as NpcId[]).filter((id) => save.npcs[id].inParty);
  if (!ids.length) return "нет";
  if (ids.length === 1) {
    const id = ids[0]!;
    return `${NPCS[id].name} (Отношения: ${save.npcs[id].rel}/100)`;
  }
  return ids.map((id) => `${NPCS[id].name} (${save.npcs[id].rel}/100)`).join(", ");
}

export function inventoryLine(save: Save): string {
  const hero = save.hero;
  if (!hero) return "пусто";
  const names = Object.entries(hero.inventory)
    .filter(([, n]) => n > 0)
    .map(([id, n]) => {
      const item = ITEMS[id];
      const name = item?.name ?? id;
      return n > 1 ? `${name} ×${n}` : name;
    });
  return names.length ? names.join(", ") : "пусто";
}

export function xpNeed(level: number): number {
  return 100 * level;
}

export function statusText(save: Save): string {
  const hero = save.hero;
  if (!hero) return "Герой ещё не вышел на тракт.";
  return [
    `Персонаж: ${hero.name} | Лвл: ${hero.level} (XP: ${hero.xp}/${xpNeed(hero.level)}) | Здоровье: ${hero.hp}/${hero.maxHp}`,
    `Локация: ${save.location || "—"} | Спутник: ${partyLine(save)}`,
    `Инвентарь: ${inventoryLine(save)} | Золото: ${hero.gold}`,
  ].join("\n");
}

export function statMod(hero: Hero, key: StatKey): number {
  return mod(hero.stats[key]);
}

export function checkLabel(stat: StatKey): string {
  return `Проверка ${STAT_GEN[stat]}`;
}
