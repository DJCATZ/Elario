import {
  armorClass,
  CLASSES,
  computeSpellMax,
  createHero,
  ENEMIES,
  ITEMS,
  mod,
  NPCS,
  proficiency,
} from "./content";
import { checkLabel, fill, formatRoll, statusText, xpNeed } from "./presentation";
import type {
  CheckSpec,
  Choice,
  CombatAction,
  CombatState,
  Draft,
  Effect,
  Hero,
  LogEntry,
  NpcId,
  Outcome,
  Req,
  RollView,
  Save,
  SkillId,
  StatKey,
} from "./types";
import { getScene } from "./world";

let seq = 1;
function uid(): string {
  seq += 1;
  return `l${Date.now().toString(36)}${seq}`;
}

function pushLog(save: Save, kind: LogEntry["kind"], text: string, roll?: RollView) {
  save.log.push({ id: uid(), kind, text, roll });
  if (save.log.length > 120) save.log.splice(0, save.log.length - 120);
}

export function blankDraft(): Draft {
  return {
    name: "",
    gender: null,
    body: null,
    race: null,
    classId: null,
    pool: [15, 14, 13, 12, 10, 8],
    assigned: {},
    picked: null,
  };
}

function freshNpc() {
  return { rel: 0, met: false, inParty: false, romance: false };
}

export function blankSave(): Save {
  const npcs = {} as Save["npcs"];
  for (const id of Object.keys(NPCS) as NpcId[]) npcs[id] = freshNpc();
  return {
    version: 1,
    phase: "title",
    createStep: 0,
    draft: blankDraft(),
    hero: null,
    sceneId: "",
    location: "",
    flags: {},
    quests: [],
    npcs,
    corruption: 0,
    log: [],
    combat: null,
    pendingLevel: 0,
    sound: true,
  };
}

export function sanitize(raw: Save | null | undefined): Save {
  const base = blankSave();
  if (!raw || raw.version !== 1) return base;
  const hero = raw.hero
    ? {
        ...raw.hero,
        skills: raw.hero.skills ?? [],
        inventory: raw.hero.inventory ?? {},
        armorBonus: raw.hero.armorBonus ?? 0,
        resources: { ...baseResources(raw.hero), ...raw.hero.resources },
      }
    : null;
  const save: Save = {
    ...base,
    ...raw,
    version: 1,
    hero,
    draft: { ...base.draft, ...raw.draft, pool: raw.draft?.pool ?? base.draft.pool, assigned: raw.draft?.assigned ?? {} },
    flags: raw.flags ?? {},
    quests: raw.quests ?? [],
    npcs: { ...base.npcs, ...raw.npcs },
    log: Array.isArray(raw.log) ? raw.log.slice(-120) : [],
    combat: raw.combat ?? null,
    pendingLevel: raw.pendingLevel ?? 0,
    corruption: raw.corruption ?? 0,
    sound: raw.sound !== false,
    phase: raw.phase ?? "title",
    createStep: raw.createStep ?? 0,
    sceneId: raw.sceneId ?? "",
    location: raw.location ?? "",
  };
  if (save.phase === "play" && (!save.hero || !getScene(save.sceneId))) {
    save.phase = save.hero ? "play" : "title";
    if (save.hero && !getScene(save.sceneId)) {
      save.sceneId = save.flags.ending ? "s_after" : "s_square";
      save.location = getScene(save.sceneId)?.location ?? save.location;
    }
  }
  return save;
}

function baseResources(hero: Hero) {
  return {
    breath: hero.race === "dragon",
    spell: 0,
    spellMax: 0,
    grit: hero.race === "human",
    classPower: true,
  };
}

const MEET: Record<string, NpcId[]> = {
  p_serge: ["serge"],
  p_lira: ["lira"],
  s_inn: ["marfa"],
  s_smith: ["bram"],
  s_shrine: ["nessa"],
  s_elder: ["elder"],
  o_kael: ["kael"],
  o_issa: ["issa"],
  sp_hall: ["issa"],
};

export function enterScene(save: Save, id: string) {
  if (id !== "r_ambush") {
    save.flags.ambushSurprised = false;
    save.flags.ambushAdvantage = false;
  }
  let scene = getScene(id);
  if (!scene) {
    pushLog(save, "system", "Тропа теряется в пепле. Ты возвращаешься туда, где помнишь хлеб.");
    scene = getScene(save.flags.ending ? "s_after" : "s_square");
  }
  if (!scene) return;
  save.sceneId = scene.id;
  save.location = scene.location;
  for (const npc of MEET[scene.id] ?? []) {
    if (save.npcs[npc]) save.npcs[npc].met = true;
  }
  if (scene.id === "s_square" || scene.id === "s_gate" || scene.id === "s_after") save.flags.reachedTown = true;
  if (scene.id === "s_after") save.flags.ending = true;
  if (scene.id === "end_ash" || scene.id === "end_god" || scene.id === "end_saint" || scene.id === "end_scatter") {
    save.flags.seedResolved = true;
  }
  const lines = [...scene.body, ...(scene.extra?.(save) ?? [])].map((line) => fill(line, save));
  pushLog(save, "narration", lines.join("\n\n"));
}

function gainXp(save: Save, amount: number) {
  const hero = save.hero;
  if (!hero || amount <= 0) return;
  hero.xp += amount;
  let guard = 0;
  while (hero.xp >= xpNeed(hero.level) && guard < 6) {
    guard += 1;
    hero.xp -= xpNeed(hero.level);
    hero.level += 1;
    const gain = Math.max(1, CLASSES[hero.classId].avg + mod(hero.stats.con));
    hero.maxHp += gain;
    hero.hp += gain;
    hero.resources.spellMax = computeSpellMax(hero.classId, hero.race, hero.level);
    hero.resources.spell = hero.resources.spellMax;
    save.pendingLevel += 1;
    pushLog(save, "system", `Новый уровень: ${hero.level}. Живучесть +${gain}.`);
  }
}

function applyEffect(save: Save, effect: Effect) {
  const hero = save.hero;
  if (!hero) return;
  switch (effect.op) {
    case "hp":
      hero.hp = Math.max(1, Math.min(hero.maxHp, hero.hp + effect.n));
      break;
    case "gold":
      hero.gold = Math.max(0, hero.gold + effect.n);
      break;
    case "item":
      hero.inventory[effect.id] = (hero.inventory[effect.id] ?? 0) + (effect.n ?? 1);
      if (effect.id === "fang") save.flags.hasFang = true;
      if (effect.id === "shard") save.flags.hasShard = true;
      break;
    case "take": {
      const left = (hero.inventory[effect.id] ?? 0) - (effect.n ?? 1);
      if (left <= 0) delete hero.inventory[effect.id];
      else hero.inventory[effect.id] = left;
      break;
    }
    case "flag":
      save.flags[effect.id] = true;
      break;
    case "unflag":
      save.flags[effect.id] = false;
      break;
    case "rel": {
      const npc = save.npcs[effect.npc];
      if (npc) npc.rel = Math.max(-100, Math.min(100, npc.rel + effect.n));
      break;
    }
    case "party": {
      const npc = save.npcs[effect.npc];
      if (npc) {
        npc.inParty = effect.in;
        npc.met = true;
      }
      break;
    }
    case "met":
      if (save.npcs[effect.npc]) save.npcs[effect.npc].met = true;
      break;
    case "romance":
      if (save.npcs[effect.npc]) save.npcs[effect.npc].romance = true;
      break;
    case "quest": {
      const quest = save.quests.find((q) => q.id === effect.id);
      if (quest) {
        quest.title = effect.title;
        quest.stage = effect.stage;
        quest.done = !!effect.done;
      } else {
        save.quests.push({ id: effect.id, title: effect.title, stage: effect.stage, done: !!effect.done });
      }
      break;
    }
    case "corrupt":
      save.corruption = Math.max(0, Math.min(100, save.corruption + effect.n));
      break;
    case "rest":
      longRest(hero);
      break;
    case "shortRest": {
      const missing = hero.maxHp - hero.hp;
      if (missing > 0) hero.hp += Math.max(1, Math.ceil(missing / 2));
      hero.resources.classPower = true;
      if (hero.resources.spell < hero.resources.spellMax) hero.resources.spell += 1;
      break;
    }
    case "equip":
      hero.weapon = effect.id;
      if (!hero.inventory[effect.id]) hero.inventory[effect.id] = 1;
      break;
    case "armorBonus":
      hero.armorBonus += 1;
      break;
    case "healFull":
      hero.hp = hero.maxHp;
      break;
    case "spendBreath":
      hero.resources.breath = false;
      break;
    case "sellJunk": {
      const fangs = hero.inventory.fang ?? 0;
      const shards = hero.inventory.shard ?? 0;
      const gold = fangs * 4 + shards * 12;
      delete hero.inventory.fang;
      delete hero.inventory.shard;
      save.flags.hasFang = false;
      save.flags.hasShard = false;
      hero.gold += gold;
      pushLog(save, "system", gold > 0 ? `Брам отсчитывает ${gold} золотых.` : "Продавать нечего.");
      break;
    }
    default: {
      const neverEffect: never = effect;
      return neverEffect;
    }
  }
}

function longRest(hero: Hero) {
  hero.hp = hero.maxHp;
  hero.resources.breath = hero.race === "dragon";
  hero.resources.grit = hero.race === "human";
  hero.resources.classPower = true;
  hero.resources.spellMax = computeSpellMax(hero.classId, hero.race, hero.level);
  hero.resources.spell = hero.resources.spellMax;
}

export function modifierFor(hero: Hero, check: CheckSpec): number {
  let total = mod(hero.stats[check.stat]);
  if (check.skill && hero.skills.includes(check.skill)) total += 2;
  if (check.stat === "wis" && (hero.inventory.amulet ?? 0) > 0) total += 1;
  if (hero.race === "dragon" && check.intimidate && check.stat === "str") total += 2;
  return total;
}

export function hasAdvantage(hero: Hero, check: CheckSpec): boolean {
  if (check.advantage) return true;
  if (hero.race === "tiefling" && check.dark) return true;
  if (hero.race === "elf" && (check.skill === "arcana" || check.arcana)) return true;
  if (hero.race === "dwarf" && check.stat === "con") return true;
  if (hero.classId === "ranger" && (check.skill === "survival" || check.survival)) return true;
  if (hero.classId === "rogue" && (check.lock || check.skill === "lock")) return true;
  return false;
}

export function rollCheck(hero: Hero, check: CheckSpec, save: Save): RollView {
  const dc = typeof check.dc === "number" ? check.dc : check.dc(save);
  const modv = modifierFor(hero, check);
  const advantage = hasAdvantage(hero, check);
  const first = d20();
  const second = advantage ? d20() : undefined;
  let natural = second != null ? Math.max(first, second) : first;
  let grit = false;
  if (natural === 1 && hero.race === "human" && hero.resources.grit) {
    hero.resources.grit = false;
    grit = true;
    natural = d20();
  }
  const other = !grit && second != null ? Math.min(first, second) : undefined;
  const total = natural + modv;
  const crit = natural === 20;
  const fumble = natural === 1;
  const success = crit || (!fumble && total >= dc);
  return {
    label: checkLabel(check.stat),
    stat: check.stat,
    d20: natural,
    d20b: other,
    mod: modv,
    total,
    dc,
    success,
    crit,
    fumble,
    grit,
  };
}

function d20(): number {
  return 1 + Math.floor(Math.random() * 20);
}

function rollDice(count: number, sides: number, bonus = 0): number {
  let sum = bonus;
  for (let i = 0; i < count; i += 1) sum += 1 + Math.floor(Math.random() * sides);
  return sum;
}

export function available(choice: Choice, save: Save): boolean {
  const req = choice.requires;
  if (!req) return true;
  return reqOk(req, save);
}

function reqOk(req: Req, save: Save): boolean {
  const hero = save.hero;
  if (!hero) return false;
  if (req.flag && !save.flags[req.flag]) return false;
  if (req.notFlag && save.flags[req.notFlag]) return false;
  if (req.anyFlag && !req.anyFlag.some((flag) => save.flags[flag])) return false;
  if (req.item && (hero.inventory[req.item] ?? 0) <= 0) return false;
  if (req.notItem && (hero.inventory[req.notItem] ?? 0) > 0) return false;
  if (req.gold != null && hero.gold < req.gold) return false;
  if (req.classId && hero.classId !== req.classId) return false;
  if (req.race && hero.race !== req.race) return false;
  if (req.party && !save.npcs[req.party]?.inParty) return false;
  if (req.notParty && save.npcs[req.notParty]?.inParty) return false;
  if (req.met && !save.npcs[req.met]?.met) return false;
  if (req.rel && (save.npcs[req.rel.npc]?.rel ?? -999) < req.rel.min) return false;
  if (req.relMax && (save.npcs[req.relMax.npc]?.rel ?? 999) > req.relMax.max) return false;
  if (req.stat && hero.stats[req.stat] < (req.min ?? 0)) return false;
  if (req.skill && !hero.skills.includes(req.skill)) return false;
  if (req.hasParty && !Object.values(save.npcs).some((npc) => npc.inParty)) return false;
  if (req.allParty && !req.allParty.every((id) => save.npcs[id]?.inParty)) return false;
  return true;
}

function go(save: Save, next: string) {
  if (next.startsWith("combat:")) {
    beginCombat(save, next.slice(7));
    return;
  }
  if (next === "return_hub") {
    enterScene(save, save.flags.ending ? "s_after" : "s_square");
    return;
  }
  if (next === "replay_ending") {
    if (save.flags.seedPlanted) enterScene(save, "end_god");
    else if (save.flags.seedBound) enterScene(save, "end_saint");
    else if (save.flags.seedScattered) enterScene(save, "end_scatter");
    else enterScene(save, "end_ash");
    return;
  }
  enterScene(save, next);
}

function resolve(save: Save, choice: Choice) {
  const hero = save.hero;
  if (!hero) return;
  if (choice.cost != null && hero.gold < choice.cost) {
    pushLog(save, "system", `Нужно ${choice.cost} золотых. Сейчас у тебя ${hero.gold}.`);
    return;
  }
  let outcome = choice.success;
  if (choice.check) {
    const roll = rollCheck(hero, choice.check, save);
    pushLog(save, "roll", formatRoll(roll), roll);
    if (roll.crit) gainXp(save, 5);
    if (!roll.success) outcome = choice.fail ?? { text: "Не выходит." };
  }
  if (outcome.text) pushLog(save, "narration", fill(outcome.text, save));
  if (outcome.xp) gainXp(save, outcome.xp);
  for (const effect of outcome.effects ?? []) applyEffect(save, effect);
  if (outcome.next) go(save, outcome.next);
}

export function applyChoice(save: Save, choiceId: string): Save {
  if (save.phase !== "play" || !save.hero) return save;
  if (save.combat || save.pendingLevel > 0) return save;
  const scene = getScene(save.sceneId);
  const choice = scene?.choices.find((item) => item.id === choiceId);
  if (!choice || !available(choice, save)) return save;
  const next = structuredClone(save);
  pushLog(next, "speech", choice.label);
  resolve(next, choice);
  return next;
}

export function startNew(draft: Draft, sound: boolean): Save {
  const save = blankSave();
  save.sound = sound;
  save.phase = "play";
  save.hero = createHero(draft);
  enterScene(save, "p_wake");
  return save;
}

export function applyLevelPick(save: Save, kind: "stat" | "skill", id: string): Save {
  if (save.pendingLevel <= 0 || save.combat || !save.hero) return save;
  const next = structuredClone(save);
  const hero = next.hero!;
  if (kind === "stat") {
    const key = id as StatKey;
    if (!(key in hero.stats) || hero.stats[key] >= 20) return save;
    hero.stats[key] += 1;
    if (key === "con") {
      hero.maxHp += 1;
      hero.hp += 1;
    }
    pushLog(next, "system", `${labelStat(key)} теперь ${hero.stats[key]} (${mod(hero.stats[key]) >= 0 ? "+" : "−"}${Math.abs(mod(hero.stats[key]))}).`);
  } else {
    const skill = id as SkillId;
    if (hero.skills.includes(skill)) return save;
    hero.skills.push(skill);
    pushLog(next, "system", `Новый навык ложится в руки: ${skillName(skill)}.`);
  }
  next.pendingLevel -= 1;
  return next;
}

function labelStat(key: StatKey): string {
  const names: Record<StatKey, string> = {
    str: "Сила",
    dex: "Ловкость",
    con: "Телосложение",
    int: "Интеллект",
    wis: "Мудрость",
    cha: "Харизма",
  };
  return names[key];
}

function skillName(id: SkillId): string {
  const names: Record<SkillId, string> = {
    athletics: "Атлетика",
    stealth: "Скрытность",
    lock: "Взлом",
    persuade: "Убеждение",
    arcana: "Аркана",
    insight: "Проницательность",
    survival: "Выживание",
    medicine: "Медицина",
  };
  return names[id];
}

export function drinkPotion(save: Save): Save {
  if (!save.hero || save.combat || (save.hero.inventory.potion ?? 0) <= 0) return save;
  const next = structuredClone(save);
  const hero = next.hero!;
  const healed = rollDice(2, 4, 2);
  const before = hero.hp;
  hero.hp = Math.min(hero.maxHp, hero.hp + healed);
  hero.inventory.potion -= 1;
  if (hero.inventory.potion <= 0) delete hero.inventory.potion;
  pushLog(next, "system", `Зелье крови-мха возвращает ${hero.hp - before} здоровья.`);
  return next;
}

export function equipWeapon(save: Save, id: string): Save {
  if (!save.hero || save.combat) return save;
  const item = ITEMS[id];
  if (!item?.weapon || (save.hero.inventory[id] ?? 0) <= 0) return save;
  const next = structuredClone(save);
  next.hero!.weapon = id;
  pushLog(next, "system", `В руке теперь: ${item.name}.`);
  return next;
}

function beginCombat(save: Save, id: string) {
  const enemy = ENEMIES[id];
  const hero = save.hero;
  if (!enemy || !hero) {
    pushLog(save, "system", "Угроза расходится сама.");
    return;
  }
  const hp = enemy.hp + Math.max(0, hero.level - 1) * 3;
  const combat: CombatState = {
    enemyId: id,
    hp,
    max: hp,
    round: 1,
    enemyMissed: false,
    defending: false,
    ambushed: !!save.flags.ambushSurprised,
  };
  save.combat = combat;
  save.flags.ambushSurprised = false;
  hero.resources.classPower = true;
  pushLog(save, "combat", enemy.intro);
  if (combat.ambushed) {
    pushLog(save, "combat", "Тебя застали раньше, чем ты успел выбрать стойку.");
    enemyTurn(save);
  }
}

function finishCombat(save: Save, victory: boolean) {
  const combat = save.combat;
  const hero = save.hero;
  if (!combat || !hero) return;
  const enemy = ENEMIES[combat.enemyId];
  save.combat = null;
  if (!enemy) return;
  if (victory) {
    for (const flag of enemy.onWin ?? []) save.flags[flag] = true;
    if ((enemy.onWin ?? []).includes("seedDestroyed")) {
      delete hero.inventory.seed;
      save.flags.hasSeed = false;
      const quest = save.quests.find((item) => item.id === "main");
      if (quest) {
        quest.stage = "Семя уничтожено в бою. Бог не взошёл.";
        quest.done = true;
      }
    }
    hero.gold += enemy.gold;
    for (const loot of enemy.loot ?? []) {
      hero.inventory[loot] = (hero.inventory[loot] ?? 0) + 1;
      if (loot === "fang") save.flags.hasFang = true;
      if (loot === "shard") save.flags.hasShard = true;
    }
    if (save.npcs.lira.inParty) save.npcs.lira.rel = Math.min(100, save.npcs.lira.rel + 4);
    if (save.npcs.kael.inParty) save.npcs.kael.rel = Math.min(100, save.npcs.kael.rel + 4);
    const bits: string[] = [];
    if (enemy.gold) bits.push(`${enemy.gold} золотых`);
    if (enemy.loot?.length) bits.push(...enemy.loot.map((id) => ITEMS[id]?.name ?? id));
    pushLog(
      save,
      "system",
      `Победа.${bits.length ? ` Добыча: ${bits.join(", ")}.` : ""} Опыт +${enemy.xp}.`,
    );
    gainXp(save, enemy.xp);
    enterScene(save, enemy.victory);
    return;
  }
  hero.hp = Math.max(1, Math.floor(hero.maxHp / 2));
  hero.gold = Math.max(0, hero.gold - 6);
  if (save.flags.hasSeed) save.corruption = Math.min(100, save.corruption + 3);
  pushLog(save, "system", "Ты выбываешь из схватки. Потеряно до 6 золотых. Смерть в этот раз проходит мимо.");
  enterScene(save, save.flags.reachedTown ? "s_downed" : enemy.defeat);
}

function enemyTurn(save: Save) {
  const combat = save.combat;
  const hero = save.hero;
  if (!combat || !hero) return;
  const enemy = ENEMIES[combat.enemyId];
  if (!enemy) return;
  const ac = armorClass(hero);
  const first = d20();
  const second = combat.defending ? d20() : undefined;
  const used = second != null ? Math.min(first, second) : first;
  const other = second != null ? Math.max(first, second) : undefined;
  combat.defending = false;
  const total = used + enemy.atk;
  const crit = used === 20;
  const fumble = used === 1;
  const hit = crit || (!fumble && total >= ac);
  const dice = other != null ? `${used}/${other}` : `${used}`;
  if (!hit) {
    combat.enemyMissed = true;
    pushLog(save, "combat", `[Атака — ${enemy.name}: d20(${dice}) + ${enemy.atk} = ${total} vs защита ${ac} — Мимо!]`);
  } else {
    combat.enemyMissed = false;
    let damage = rollDice(enemy.dmg[0] * (crit ? 2 : 1), enemy.dmg[1], enemy.dmg[2]);
    damage = Math.max(1, damage);
    let extra = "";
    if (enemy.poison && hero.race === "dwarf") {
      damage = Math.floor(damage / 2);
      extra = " Стойкость дворфа гасит половину яда.";
    }
    hero.hp -= damage;
    pushLog(
      save,
      "combat",
      `[Атака — ${enemy.name}: d20(${dice}) + ${enemy.atk} = ${total} vs защита ${ac} — ${crit ? "Критическое попадание" : "Попадание"}! Урон ${damage}.]${extra}`,
    );
    if (hero.hp <= 0) {
      finishCombat(save, false);
      return;
    }
  }
  combat.round += 1;
}

export function canSneak(hero: Hero, combat: CombatState): boolean {
  return hero.classId === "rogue" && ((combat.round === 1 && !combat.ambushed) || combat.enemyMissed);
}

function strike(
  save: Save,
  stat: StatKey,
  dice: [number, number],
  bonus: number,
  label: string,
  advantage: boolean,
  flat = 0,
) {
  const combat = save.combat;
  const hero = save.hero;
  if (!combat || !hero) return;
  const enemy = ENEMIES[combat.enemyId];
  if (!enemy) return;
  const attackMod = mod(hero.stats[stat]) + proficiency(hero.level) + bonus;
  const first = d20();
  const second = advantage ? d20() : undefined;
  const used = second != null ? Math.max(first, second) : first;
  const other = second != null ? Math.min(first, second) : undefined;
  const total = used + attackMod;
  const crit = used === 20;
  const fumble = used === 1;
  const hit = crit || (!fumble && total >= enemy.ac);
  const shown = other != null ? `${used}/${other}` : `${used}`;
  const sign = attackMod >= 0 ? `+ ${attackMod}` : `− ${Math.abs(attackMod)}`;
  if (!hit) {
    pushLog(save, "combat", `[${label}: d20(${shown}) ${sign} = ${total} vs защита ${enemy.ac} — ${fumble ? "Критический промах" : "Мимо"}!]`);
    enemyTurn(save);
    return;
  }
  let damage = rollDice(dice[0] * (crit ? 2 : 1), dice[1], mod(hero.stats[stat]) + flat);
  if (canSneak(hero, combat) && label.startsWith("Удар")) damage += rollDice(1, 6, 0);
  damage = Math.max(1, damage);
  combat.hp = Math.max(0, combat.hp - damage);
  pushLog(
    save,
    "combat",
    `[${label}: d20(${shown}) ${sign} = ${total} vs защита ${enemy.ac} — ${crit ? "Критическое попадание" : "Попадание"}! Урон ${damage}.]`,
  );
  if (combat.hp <= 0) finishCombat(save, true);
  else enemyTurn(save);
}

export function applyCombat(save: Save, action: CombatAction): Save {
  if (!save.combat || !save.hero) return save;
  const next = structuredClone(save);
  const hero = next.hero!;
  const combat = next.combat!;
  const enemy = ENEMIES[combat.enemyId];
  if (!enemy) return save;
  const weapon = ITEMS[hero.weapon];
  const stat = weapon?.stat ?? "str";
  const dice = weapon?.dice ?? ([1, 4] as [number, number]);
  const hitBonus = weapon?.hit ?? 0;
  const dmgBonus = weapon?.dmgBonus ?? 0;

  if (action === "attack" || action === "power") {
    if (action === "power") {
      if (!hero.resources.classPower || (hero.classId !== "warrior" && hero.classId !== "ranger")) {
        pushLog(next, "system", "Этот приём сейчас не собрать.");
        return next;
      }
      hero.resources.classPower = false;
      if (hero.classId === "warrior") {
        strike(next, stat, [dice[0], dice[1]], hitBonus, "Рассекающий удар", true, 2 + dmgBonus);
        return next;
      }
      strike(next, "dex", hero.weapon === "bow" ? dice : [1, 8], hitBonus, "Меткий выстрел", true);
      return next;
    }
    const sneak = canSneak(hero, combat);
    strike(next, stat, dice, hitBonus, sneak ? "Удар из тени" : "Твоя атака", false, dmgBonus);
    return next;
  }

  if (action === "smite" || action === "heal") {
    if (hero.classId !== "cleric" || !hero.resources.classPower) {
      pushLog(next, "system", "Свет печати ещё не вернулся.");
      return next;
    }
    hero.resources.classPower = false;
    if (action === "heal") {
      const healed = Math.max(1, rollDice(1, 8, mod(hero.stats.wis)));
      const before = hero.hp;
      hero.hp = Math.min(hero.maxHp, hero.hp + healed);
      pushLog(next, "combat", `Свет лечения смыкает рану: +${hero.hp - before} здоровья.`);
      enemyTurn(next);
      return next;
    }
    strike(next, "wis", [1, 8], 0, "Кара печати", false);
    return next;
  }

  if (action === "spell") {
    if (hero.resources.spell <= 0) {
      pushLog(next, "system", "Искра Архива молчит до отдыха.");
      return next;
    }
    hero.resources.spell -= 1;
    const spellDice: [number, number] = hero.classId === "sorcerer" ? [2, 6] : [1, 6];
    strike(next, "int", spellDice, 0, "Искра Архива", false);
    return next;
  }

  if (action === "breath") {
    if (hero.race !== "dragon" || !hero.resources.breath) {
      pushLog(next, "system", "В горле больше нет пепла.");
      return next;
    }
    hero.resources.breath = false;
    const damage = Math.max(1, rollDice(2, 6, 0));
    combat.hp = Math.max(0, combat.hp - damage);
    pushLog(next, "combat", `Дыхание пепла накрывает ${enemy.name}. Урон ${damage}.`);
    if (combat.hp <= 0) finishCombat(next, true);
    else enemyTurn(next);
    return next;
  }

  if (action === "seed") {
    if (!next.flags.hasSeed) {
      pushLog(next, "system", "Семя больше не отвечает.");
      return next;
    }
    const count = next.corruption >= 40 ? 3 : 2;
    const damage = Math.max(1, rollDice(count, 6, mod(hero.stats.cha)));
    combat.hp = Math.max(0, combat.hp - damage);
    hero.hp = Math.max(1, hero.hp - 2);
    next.corruption = Math.min(100, next.corruption + 6);
    pushLog(next, "combat", `Шёпот Жатвы бьёт ${enemy.name} на ${damage}. Тебе достаётся 2 урона, и семя становится ближе.`);
    if (combat.hp <= 0) finishCombat(next, true);
    else enemyTurn(next);
    return next;
  }

  if (action === "potion") {
    if ((hero.inventory.potion ?? 0) <= 0) {
      pushLog(next, "system", "Флакон пуст.");
      return next;
    }
    const healed = rollDice(2, 4, 2);
    const before = hero.hp;
    hero.hp = Math.min(hero.maxHp, hero.hp + healed);
    hero.inventory.potion -= 1;
    if (hero.inventory.potion <= 0) delete hero.inventory.potion;
    pushLog(next, "combat", `Ты пьёшь зелье на ходу: +${hero.hp - before} здоровья.`);
    enemyTurn(next);
    return next;
  }

  if (action === "defend") {
    combat.defending = true;
    pushLog(next, "combat", "Ты закрываешься — клинком, плечом, плащом. Следующий удар придётся им искать.");
    enemyTurn(next);
    return next;
  }

  const roll = rollCheck(hero, { stat: "dex", dc: enemy.fleeDc, skill: "stealth" }, next);
  pushLog(next, "roll", formatRoll(roll), roll);
  if (roll.success) {
    next.combat = null;
    pushLog(next, "narration", "Ты выскальзываешь из схватки. Добычи нет — зато есть пульс.");
    if (roll.crit) gainXp(next, 5);
    go(next, enemy.flee);
  } else {
    pushLog(next, "narration", "Отступить не выходит. Враг пользуется заминкой.");
    enemyTurn(next);
  }
  return next;
}

const SUCCESS: Record<StatKey, string[]> = {
  str: ["Сила берёт своё. Мир недовольно уступает на полшага."],
  dex: ["Тело успевает раньше беды. Получается чисто, почти красиво."],
  con: ["Ты выдерживаешь. Не геройски — основательно, как стена."],
  int: ["Нить смысла находится. Не вся, но достаточная, чтобы не идти вслепую."],
  wis: ["Чутьё не врёт. Ты замечаешь то, что сцена не хотела показывать сразу."],
  cha: ["Слова садятся куда надо. Даже семя на миг слушает, не перебивая."],
};

const FAILURE: Record<StatKey, string[]> = {
  str: ["Силы не хватает ровно на палец. Этого пальца миру достаточно."],
  dex: ["Опора уходит. Ты остаёшься на ногах, но затея уже шумит."],
  con: ["Тело просит пощады раньше гордости. Приходится отступить на вдох."],
  int: ["Мысль путается, как мокрая карта. Ясного ответа нет."],
  wis: ["Ты смотришь — и всё равно смотришь мимо. Так тоже бывает."],
  cha: ["Речь звучит правильно и не работает. Слушатель остаётся при своём."],
};

function pick<T>(list: T[]): T {
  return list[Math.floor(Math.random() * list.length)]!;
}

const TAG_WORDS: { re: RegExp; tags: string[] }[] = [
  { re: /атак|удар|бой|сраж|бей|режь/, tags: ["fight"] },
  { re: /скры|крад|тихи|тихо|проскольз|канав/, tags: ["stealth"] },
  { re: /уговор|убед|обман|солг|попрос|говор|речь|спокойн/, tags: ["talk"] },
  { re: /осмотр|изуч|чита|надпис|линз|смотр|дума/, tags: ["lore"] },
  { re: /след|троп|выжив|овраг/, tags: ["survival"] },
  { re: /отдых|сон|ночлег|поспа|высп/, tags: ["rest"] },
  { re: /флирт|поцел|обня|любов|нежно|бдени|ночью с|остаться с/, tags: ["romance"] },
  { re: /купить|меч|зель|кольч|кузн|прод/, tags: ["shop"] },
  { re: /семен|семя|жат|посаж|связ|рассе/, tags: ["seed"] },
  { re: /кольц|серж/, tags: ["ring"] },
  { re: /шпил/, tags: ["spire"] },
  { re: /горнил|уничтож|сжечь|огон/, tags: ["forge", "destroy"] },
  { re: /обсерв|карт/, tags: ["obs", "map"] },
  { re: /трактир|таверн|марф|ложк/, tags: ["inn"] },
  { re: /свят|нисс|молит|алтар/, tags: ["shrine"] },
  { re: /старост|ивен/, tags: ["elder"] },
  { re: /лир/, tags: ["lira"] },
  { re: /каэл|каел/, tags: ["kael"] },
  { re: /назад|вернут|уйти|площад|хватит/, tags: ["back"] },
  { re: /охот|шакал/, tags: ["hunt"] },
  { re: /деревн|делам|кузн|трактир/, tags: ["town"] },
  { re: /в путь|околиц|собрать/, tags: ["travel"] },
  { re: /лес|чащ|железн/, tags: ["forest"] },
  { re: /угрож|прогон|фанатик|убер/, tags: ["threaten"] },
  { re: /вместе|присоедин|позвать|принять помощ/, tags: ["accept"] },
];

function scoreChoice(choice: Choice, text: string): number {
  let score = 0;
  const tags = new Set(choice.tags ?? []);
  for (const group of TAG_WORDS) {
    if (!group.re.test(text)) continue;
    if (group.tags.some((tag) => tags.has(tag))) score += 3;
  }
  const label = choice.label.toLowerCase();
  for (const word of text.split(/\s+/)) {
    if (word.length > 4 && label.includes(word.slice(0, 6))) score += 2;
  }
  return score;
}

function inferStat(text: string): { stat: StatKey; skill?: SkillId } {
  if (/атак|удар|лома|сил|тащ/.test(text)) return { stat: "str", skill: "athletics" };
  if (/скры|крад|ловк|замок|взлом/.test(text)) return { stat: "dex", skill: "stealth" };
  if (/уговор|обман|реч|фраз|льст|фл/.test(text)) return { stat: "cha", skill: "persuade" };
  if (/чита|маг|дума|изуч|надпис|линз/.test(text)) return { stat: "int", skill: "arcana" };
  if (/молит|след|слуша|чувств|леч|троп/.test(text)) return { stat: "wis", skill: "insight" };
  return { stat: "wis", skill: "insight" };
}

export function applyFreeText(save: Save, raw: string): Save {
  const text = raw.trim();
  if (!text || save.phase !== "play" || !save.hero) return save;
  const next = structuredClone(save);
  if (next.pendingLevel > 0 && !next.combat) {
    pushLog(next, "system", "Сначала прими дар нового уровня.");
    return next;
  }
  if (next.combat) return combatFromText(next, text);
  pushLog(next, "speech", text);
  const lower = text.toLowerCase();
  if (/^(инвентар|сумк|кто я|статус|квест)/.test(lower)) {
    pushLog(next, "system", statusText(next));
    return next;
  }
  if (tryRomance(next, lower)) return next;
  if (tryRest(next, lower)) return next;
  const scene = getScene(next.sceneId);
  const choices = scene?.choices.filter((choice) => available(choice, next)) ?? [];
  let best: Choice | null = null;
  let bestScore = 0;
  let tie = false;
  for (const choice of choices) {
    const score = scoreChoice(choice, lower);
    if (score > bestScore) {
      best = choice;
      bestScore = score;
      tie = false;
    } else if (score === bestScore && score > 0) tie = true;
  }
  if (best && bestScore >= 3 && !tie) {
    resolve(next, best);
    return next;
  }
  for (const hint of HINTS) {
    if (hint.re.test(lower) && hint.when(next)) {
      pushLog(next, "system", hint.text);
      return next;
    }
  }
  const inferred = inferStat(lower);
  const roll = rollCheck(next.hero!, { stat: inferred.stat, dc: 13, skill: inferred.skill }, next);
  pushLog(next, "roll", formatRoll(roll), roll);
  pushLog(next, "narration", roll.success ? pick(SUCCESS[inferred.stat]) : pick(FAILURE[inferred.stat]));
  pushLog(next, "system", "Большая тропа от этого не сворачивает — рядом всё ещё лежат ясные шаги, если затея была иной.");
  if (roll.success) gainXp(next, 5);
  else if (roll.fumble) {
    next.hero!.hp = Math.max(1, next.hero!.hp - 1);
    pushLog(next, "system", "Мелочь оборачивается царапиной. −1 здоровье.");
  }
  return next;
}

function tryRest(save: Save, text: string): boolean {
  if (!/отдых|поспа|сон|ночлег|переноч|высп/.test(text)) return false;
  const hero = save.hero!;
  if (save.sceneId === "s_inn") {
    if (hero.gold < 3) {
      pushLog(save, "system", "Марфа качает головой: ночлег стоит три монеты.");
      return true;
    }
    hero.gold -= 3;
    longRest(hero);
    save.npcs.marfa.rel = Math.min(100, save.npcs.marfa.rel + 4);
    pushLog(save, "narration", "Ты спишь под чужой крышей. Утро возвращает силы, искры и дыхание — всё, что положено живым.");
    gainXp(save, 5);
    return true;
  }
  if (save.sceneId === "s_shrine" || save.sceneId === "s_after" || save.sceneId === "s_square") {
    longRest(hero);
    pushLog(save, "narration", "Ты находишь место, где можно закрыть глаза и не сторожить каждый шорох. Тело собирается заново.");
    gainXp(save, 5);
    return true;
  }
  pushLog(save, "system", "Здесь нельзя забыться. Сначала стены, алтарь или площадь Солницы.");
  return true;
}

function tryRomance(save: Save, text: string): boolean {
  if (!/флирт|поцел|обня|любов|нежно|рядом ноч|остаться с/.test(text)) return false;
  let id: NpcId | null = null;
  if (text.includes("лир")) id = "lira";
  else if (text.includes("каэл") || text.includes("каел")) id = "kael";
  else if (text.includes("марф")) id = "marfa";
  else if (save.npcs.lira.inParty) id = "lira";
  else if (save.npcs.kael.inParty) id = "kael";
  else if (save.sceneId === "s_inn") id = "marfa";
  if (!id) {
    pushLog(save, "narration", "Некому ответить на эту теплоту. Тракт глух, и семя — плохой собеседник для нежности.");
    return true;
  }
  const npc = save.npcs[id];
  const present = npc.inParty || (id === "marfa" && (save.sceneId === "s_inn" || save.sceneId === "s_town"));
  if (!present || !npc.met) {
    pushLog(save, "narration", `${NPCS[id].name} сейчас не здесь. Чувство без адреса остаётся при тебе.`);
    return true;
  }
  if (npc.romance) {
    pushLog(save, "narration", "Между вами уже есть близость. Она не требует новой клятвы — только не предать её мелким страхом.");
    npc.rel = Math.min(100, npc.rel + 2);
    return true;
  }
  if (npc.rel < 40) {
    npc.rel = Math.min(100, npc.rel + 4);
    pushLog(save, "narration", "Тепло замечено. Для ночи, которую не пересказывают, ещё рано — или ещё не то место. Но отступлено на шаг меньше.");
    return true;
  }
  npc.rel = Math.min(100, npc.rel + 12);
  npc.romance = true;
  const flag = id === "lira" ? "romanceLira" : id === "kael" ? "romanceKael" : "romanceMarfa";
  save.flags[flag] = true;
  gainXp(save, 15);
  const scene = id === "lira" ? "romance_lira" : id === "kael" ? "romance_kael" : "romance_marfa";
  enterScene(save, scene);
  return true;
}

function combatFromText(save: Save, text: string): Save {
  const lower = text.toLowerCase();
  pushLog(save, "speech", text);
  const act = (action: CombatAction) => applyCombat(unspeech(save), action);
  if (/зел|пить|леч/.test(lower) && !/кара|свет/.test(lower)) return act("potion");
  if (/дых/.test(lower)) return act("breath");
  if (/шёпот|шепот|семен|семя/.test(lower)) return act("seed");
  if (/искр|заклин|маги/.test(lower)) return act("spell");
  if (/кара/.test(lower)) return act("smite");
  if (/свет|исцел|молитв/.test(lower)) return act("heal");
  if (/рассек|метк|выстрел|приём|прием/.test(lower)) return act("power");
  if (/защит|блок|щит|закро/.test(lower)) return act("defend");
  if (/бег|отступ|беж|сбежать/.test(lower)) return act("flee");
  if (/атак|удар|бей|режь/.test(lower)) return act("attack");
  pushLog(save, "system", "В бою время короткое: атака, защита, зелье, искра, шёпот, отступление.");
  return save;
}

function unspeech(save: Save): Save {
  const copy = structuredClone(save);
  const last = copy.log[copy.log.length - 1];
  if (last?.kind === "speech") copy.log.pop();
  return copy;
}

const HINTS: { re: RegExp; when: (s: Save) => boolean; text: string }[] = [
  {
    re: /железн|в лес|чащ/,
    when: (s) => s.sceneId === "s_square" || s.sceneId === "s_town",
    text: "Чаща начинается за околицей. С площади открой «В путь».",
  },
  {
    re: /обсерватор/,
    when: (s) => !s.flags.hasLens && !s.flags.seedResolved,
    text: "Без линзы Архива затопленный купол — просто лужа. Сначала Железный лес.",
  },
  {
    re: /шпил/,
    when: (s) => !s.flags.hasMap && !s.flags.seedResolved,
    text: "Без карты Шпиль водит кругами. Карта спит в обсерватории.",
  },
  {
    re: /горнил|сжечь сем/,
    when: (s) => !s.flags.hasLens && !s.flags.seedResolved,
    text: "Горнило открывается тем, кто уже прочёл печать. Сначала линза в лесу.",
  },
];

export function visibleChoices(save: Save): Choice[] {
  const scene = getScene(save.sceneId);
  if (!scene) return [];
  return scene.choices.filter((choice) => available(choice, save));
}
