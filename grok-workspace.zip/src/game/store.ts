import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  applyChoice,
  applyCombat,
  applyFreeText,
  applyLevelPick,
  blankDraft,
  blankSave,
  drinkPotion,
  equipWeapon,
  sanitize,
  startNew,
} from "./engine";
import type { CombatAction, Draft, Save } from "./types";

export type SheetId = "hero" | "bag" | "people" | "quests" | "help" | null;

type Store = {
  save: Save;
  sheet: SheetId;
  askNew: boolean;
  setSheet: (sheet: SheetId) => void;
  setAskNew: (ask: boolean) => void;
  patchDraft: (patch: Partial<Draft>) => void;
  setStep: (step: number) => void;
  toTitle: () => void;
  toCreate: () => void;
  continueGame: () => void;
  begin: () => void;
  choose: (id: string) => void;
  freeText: (text: string) => void;
  combat: (action: CombatAction) => void;
  levelPick: (kind: "stat" | "skill", id: string) => void;
  equip: (id: string) => void;
  drink: () => void;
  toggleSound: () => void;
  reset: () => void;
};

export const useGame = create<Store>()(
  persist(
    (set, get) => ({
      save: blankSave(),
      sheet: null,
      askNew: false,
      setSheet: (sheet) => set({ sheet }),
      setAskNew: (askNew) => set({ askNew }),
      patchDraft: (patch) =>
        set((state) => ({ save: { ...state.save, draft: { ...state.save.draft, ...patch } } })),
      setStep: (createStep) => set((state) => ({ save: { ...state.save, createStep } })),
      toTitle: () => set((state) => ({ save: { ...state.save, phase: "title" }, sheet: null, askNew: false })),
      toCreate: () =>
        set((state) => ({
          save: { ...state.save, phase: "create", createStep: 0, draft: blankDraft() },
          sheet: null,
          askNew: false,
        })),
      continueGame: () =>
        set((state) => ({ save: { ...state.save, phase: "play" }, sheet: null })),
      begin: () => {
        const { save } = get();
        set({ save: startNew(save.draft, save.sound), sheet: null, askNew: false });
      },
      choose: (id) => set({ save: applyChoice(get().save, id) }),
      freeText: (text) => set({ save: applyFreeText(get().save, text) }),
      combat: (action) => set({ save: applyCombat(get().save, action) }),
      levelPick: (kind, id) => set({ save: applyLevelPick(get().save, kind, id) }),
      equip: (id) => set({ save: equipWeapon(get().save, id) }),
      drink: () => set({ save: drinkPotion(get().save) }),
      toggleSound: () => set((state) => ({ save: { ...state.save, sound: !state.save.sound } })),
      reset: () => set({ save: { ...blankSave(), sound: get().save.sound }, sheet: null, askNew: false }),
    }),
    {
      name: "eleria-save-v1",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined"
          ? { getItem: () => null, setItem: () => undefined, removeItem: () => undefined }
          : localStorage,
      ),
      partialize: (state) => ({ save: state.save }),
      merge: (persisted, current) => {
        const saved = (persisted as { save?: Save } | undefined)?.save;
        return { ...current, save: sanitize(saved) };
      },
    },
  ),
);
