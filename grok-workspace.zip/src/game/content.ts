import type {
  ArmorId,
  BodyId,
  ClassId,
  Draft,
  Hero,
  NpcId,
  RaceId,
  SkillId,
  StatKey,
  Stats,
} from "./types";

export const STAT_KEYS: StatKey[] = ["str", "dex", "con", "int", "wis", "cha"];

export const STAT_FULL: Record<StatKey, string> = {
  str: "Сила",
  dex: "Ловкость",
  con: "Телосложение",
  int: "Интеллект",
  wis: "Мудрость",
  cha: "Харизма",
};

export const STAT_GEN: Record<StatKey, string> = {
  str: "Силы",
  dex: "Ловкости",
  con: "Телосложения",
  int: "Интеллекта",
  wis: "Мудрости",
  cha: "Харизмы",
};

export const STAT_SHORT: Record<StatKey, string> = {
  str: "СИЛ",
  dex: "ЛОВ",
  con: "ТЕЛ",
  int: "ИНТ",
  wis: "МУД",
  cha: "ХАР",
};

export function mod(score: number): number {
  return Math.floor((score - 10) / 2);
}

export function proficiency(level: number): number {
  return 2 + Math.floor((level - 1) / 4);
}

export type SkillDef = { id: SkillId; name: string; stat: StatKey; blurb: string };

export const SKILLS: SkillDef[] = [
  { id: "athletics", name: "Атлетика", stat: "str", blurb: "+2 к силовым проверкам, где решает тело." },
  { id: "stealth", name: "Скрытность", stat: "dex", blurb: "+2, когда надо стать тенью." },
  { id: "lock", name: "Взлом", stat: "dex", blurb: "+2 к замкам, ловушкам и чужим механизмам." },
  { id: "persuade", name: "Убеждение", stat: "cha", blurb: "+2 к речам, обману и теплу в голосе." },
  { id: "arcana", name: "Аркана", stat: "int", blurb: "+2 к машинам предков и осколкам магии." },
  { id: "insight", name: "Проницательность", stat: "wis", blurb: "+2, чтобы слышать, о чём молчат." },
  { id: "survival", name: "Выживание", stat: "wis", blurb: "+2 к следу, ночи и дурным дорогам." },
  { id: "medicine", name: "Медицина", stat: "wis", blurb: "+2 к ранам, ядам и молитвам плоти." },
];

export type RaceDef = {
  id: RaceId;
  name: string;
  bonus: string;
  trait: string;
  mods: Partial<Stats>;
};

export const RACES: Record<RaceId, RaceDef> = {
  human: {
    id: "human",
    name: "Человек",
    bonus: "+1 ко всем характеристикам",
    trait: "Упрямство живых: один раз за отдых провал с единицы на кости перебрасывается.",
    mods: { str: 1, dex: 1, con: 1, int: 1, wis: 1, cha: 1 },
  },
  elf: {
    id: "elf",
    name: "Высший эльф",
    bonus: "+2 к интеллекту",
    trait: "Врождённая магия: искра Архива и преимущество, когда читаешь руины.",
    mods: { int: 2 },
  },
  dwarf: {
    id: "dwarf",
    name: "Лесной дворф",
    bonus: "+2 к телосложению",
    trait: "Каменная печень: преимущество на теле, яд бьёт вполсилы.",
    mods: { con: 2 },
  },
  dragon: {
    id: "dragon",
    name: "Драконорожденный",
    bonus: "+2 к силе",
    trait: "Дыхание пепла раз за долгий отдых. Угрозы звучат тяжелее.",
    mods: { str: 2 },
  },
  tiefling: {
    id: "tiefling",
    name: "Теневой тифлинг",
    bonus: "+2 к харизме",
    trait: "Ночное зрение: преимущество, когда тьма должна мешать.",
    mods: { cha: 2 },
  },
};

export type ClassDef = {
  id: ClassId;
  name: string;
  bonus: string;
  trait: string;
  mods: Partial<Stats>;
  hp: number;
  avg: number;
  armor: ArmorId;
  weapon: string;
  skill: SkillId;
  gold: number;
};

export const CLASSES: Record<ClassId, ClassDef> = {
  warrior: {
    id: "warrior",
    name: "Воин",
    bonus: "+2 к силе, тяжёлая броня",
    trait: "Рассекающий удар — раз за бой, с преимуществом.",
    mods: { str: 2 },
    hp: 12,
    avg: 7,
    armor: "heavy",
    weapon: "arming_sword",
    skill: "athletics",
    gold: 12,
  },
  sorcerer: {
    id: "sorcerer",
    name: "Чародей",
    bonus: "+1 к интеллекту и харизме",
    trait: "Искры Архива вместо доспеха. Покров держит тонкую защиту.",
    mods: { int: 1, cha: 1 },
    hp: 6,
    avg: 4,
    armor: "shroud",
    weapon: "staff",
    skill: "arcana",
    gold: 16,
  },
  rogue: {
    id: "rogue",
    name: "Плут",
    bonus: "+2 к ловкости",
    trait: "Замки слушаются легче. Первый удар часто приходит из тени.",
    mods: { dex: 2 },
    hp: 8,
    avg: 5,
    armor: "light",
    weapon: "dagger",
    skill: "stealth",
    gold: 22,
  },
  cleric: {
    id: "cleric",
    name: "Жрец",
    bonus: "+2 к мудрости",
    trait: "Кара печати или свет лечения — раз за бой.",
    mods: { wis: 2 },
    hp: 10,
    avg: 6,
    armor: "medium",
    weapon: "mace",
    skill: "medicine",
    gold: 14,
  },
  ranger: {
    id: "ranger",
    name: "Следопыт",
    bonus: "+1 к ловкости и мудрости",
    trait: "Чутьё тропы и меткий выстрел раз за бой.",
    mods: { dex: 1, wis: 1 },
    hp: 10,
    avg: 6,
    armor: "light",
    weapon: "bow",
    skill: "survival",
    gold: 18,
  },
};

export type BodyDef = {
  id: BodyId;
  name: string;
  bonus: string;
  phrase: string;
  mods: Partial<Stats>;
};

export const BODIES: Record<BodyId, BodyDef> = {
  frail: {
    id: "frail",
    name: "Хрупкое",
    bonus: "ЛОВ +1, ТЕЛ −1",
    phrase: "хрупкое, точное тело",
    mods: { dex: 1, con: -1 },
  },
  athletic: {
    id: "athletic",
    name: "Атлетическое",
    bonus: "СИЛ +1, ЛОВ +1, ТЕЛ −1",
    phrase: "атлетическое, быстрое сложение",
    mods: { str: 1, dex: 1, con: -1 },
  },
  massive: {
    id: "massive",
    name: "Массивное",
    bonus: "СИЛ +1, ТЕЛ +1, ЛОВ −1",
    phrase: "массивная, трудносдвигаемая стать",
    mods: { str: 1, con: 1, dex: -1 },
  },
  soft: {
    id: "soft",
    name: "Пышное",
    bonus: "ХАР +1, ТЕЛ +1, ЛОВ −1",
    phrase: "мягкая, заметная полнота",
    mods: { cha: 1, con: 1, dex: -1 },
  },
};

export const GENDERS: { id: "m" | "f" | "x"; name: string; hint: string }[] = [
  { id: "m", name: "Мужской", hint: "Мир скажет «путник»." },
  { id: "f", name: "Женский", hint: "Мир скажет «путница»." },
  { id: "x", name: "Иной", hint: "Мир будет звать тебя по имени." },
];

export type ItemDef = {
  name: string;
  desc: string;
  quest?: boolean;
  weapon?: boolean;
  dice?: [number, number];
  stat?: StatKey;
  hit?: number;
  dmgBonus?: number;
  heal?: [number, number, number];
};

export const ITEMS: Record<string, ItemDef> = {
  seed: {
    name: "Семя Жатвы",
    quest: true,
    desc: "Чёрное, тёплое, размером с кулак. Шепчет твоим именем и не любит чужие ладони.",
  },
  ring: {
    name: "Кольцо Сержа",
    quest: true,
    desc: "Печать стража, треснувшая поперёк солнечного луча.",
  },
  lens: {
    name: "Линза Архива",
    quest: true,
    desc: "Стекло предков. В нём звёзды стоят ближе, чем имеют право.",
  },
  star_map: {
    name: "Карта Шпиля",
    quest: true,
    desc: "Не бумага — тонкая пластина. Дорога на ней пульсирует, если семя рядом.",
  },
  potion: {
    name: "Зелье крови-мха",
    desc: "Горькое. Лечит 2d4+2.",
    heal: [2, 4, 2],
  },
  arming_sword: {
    name: "Походный меч",
    desc: "Честный клинок без родословной. 1d8 + сила.",
    weapon: true,
    dice: [1, 8],
    stat: "str",
  },
  dagger: {
    name: "Кинжал",
    desc: "Короткий, тихий. 1d4 + ловкость.",
    weapon: true,
    dice: [1, 4],
    stat: "dex",
  },
  bow: {
    name: "Короткий лук",
    desc: "Тетива пахнет воском. 1d6 + ловкость.",
    weapon: true,
    dice: [1, 6],
    stat: "dex",
  },
  mace: {
    name: "Булава рассвета",
    desc: "Тяжёлая головка с выщербленным диском. 1d6 + сила.",
    weapon: true,
    dice: [1, 6],
    stat: "str",
  },
  staff: {
    name: "Посох архива",
    desc: "В древке спит латунная жила. 1d6 + интеллект.",
    weapon: true,
    dice: [1, 6],
    stat: "int",
  },
  iron_sword: {
    name: "Меч Брама",
    desc: "Кузнец клянётся, что сталь помнит лес. 1d8+1 и точнее на единицу.",
    weapon: true,
    dice: [1, 8],
    stat: "str",
    hit: 1,
    dmgBonus: 1,
  },
  amulet: {
    name: "Солнечная нить",
    desc: "Дар Ниссы. +1 к проверкам мудрости.",
  },
  fang: {
    name: "Уголь клыка",
    desc: "Порченый трофей. Брам даст за него несколько монет.",
  },
  shard: {
    name: "Архивный осколок",
    desc: "Тёплый кусок стекла. В кузне за него платят.",
  },
};

export type EnemyDef = {
  id: string;
  name: string;
  hp: number;
  ac: number;
  atk: number;
  dmg: [number, number, number];
  xp: number;
  gold: number;
  loot?: string[];
  intro: string;
  victory: string;
  defeat: string;
  flee: string;
  fleeDc: number;
  poison?: boolean;
  onWin?: string[];
};

export const ENEMIES: Record<string, EnemyDef> = {
  wolves: {
    id: "wolves",
    name: "Стая порченой дичи",
    hp: 16,
    ac: 12,
    atk: 4,
    dmg: [1, 6, 2],
    xp: 35,
    gold: 8,
    loot: ["fang"],
    intro: "Порченая дичь больше не боится огня. Глаза — как мокрый уголь, и голод у них общий.",
    victory: "r_after",
    defeat: "defeat_road",
    flee: "r_flee",
    fleeDc: 13,
  },
  scouts: {
    id: "scouts",
    name: "Дозор Круга Корня",
    hp: 18,
    ac: 13,
    atk: 5,
    dmg: [1, 8, 1],
    xp: 40,
    gold: 14,
    poison: true,
    intro: "Дозорные поднимают корни, как копья. «Семя. Отдай — и уйдёшь с руками».",
    victory: "f_ruins",
    defeat: "s_downed",
    flee: "f_retreat",
    fleeDc: 14,
  },
  construct: {
    id: "construct",
    name: "Архивариус без лица",
    hp: 24,
    ac: 15,
    atk: 5,
    dmg: [1, 10, 1],
    xp: 55,
    gold: 6,
    loot: ["shard"],
    intro: "Из чёрной воды встаёт латунь и стекло. У него нет лица — только голод чужой памяти.",
    victory: "o_map",
    defeat: "s_downed",
    flee: "o_shore",
    fleeDc: 15,
  },
  guardian: {
    id: "guardian",
    name: "Страж Шпиля",
    hp: 28,
    ac: 15,
    atk: 6,
    dmg: [1, 10, 2],
    xp: 70,
    gold: 18,
    intro: "На лестнице стоит доспех, который помнит хозяина лучше, чем хозяин помнил себя.",
    victory: "sp_hall",
    defeat: "s_downed",
    flee: "sp_stairs",
    fleeDc: 15,
  },
  issa: {
    id: "issa",
    name: "Мать Корня Исса",
    hp: 34,
    ac: 16,
    atk: 7,
    dmg: [2, 6, 2],
    xp: 100,
    gold: 0,
    poison: true,
    onWin: ["killedIssa", "seedDestroyed", "seedResolved"],
    intro: "Исса перестаёт уговаривать. Корни делают шаг вместо неё.",
    victory: "end_ash",
    defeat: "s_downed",
    flee: "sp_stairs",
    fleeDc: 16,
  },
  hunt: {
    id: "hunt",
    name: "Пепельный шакал",
    hp: 14,
    ac: 12,
    atk: 4,
    dmg: [1, 6, 1],
    xp: 22,
    gold: 7,
    loot: ["fang"],
    intro: "Шакал выходит на тракт. Его привлёк запах семени — или твоя усталость.",
    victory: "hunt_done",
    defeat: "s_downed",
    flee: "return_hub",
    fleeDc: 12,
  },
};

export type NpcDef = { name: string; role: string; about: string };

export const NPCS: Record<NpcId, NpcDef> = {
  lira: {
    name: "Лира Вейн",
    role: "Теневая контрабандистка",
    about: "Тифлинг, которая водит людей мимо чужих клятв. Смеётся раньше, чем доверяет.",
  },
  kael: {
    name: "Брат Каэл",
    role: "Паладин Пепельной Печати",
    about: "Верит, что сжечь семя — милость. Вере не мешает быть добрым, и это опаснее фанатизма.",
  },
  issa: {
    name: "Исса, Мать Корня",
    role: "Голос Круга",
    about: "Хочет посадить Жатву в Шпиль и стать ей языком. Не злодейка из ярмарки — голодная надежда.",
  },
  nessa: {
    name: "Нисса",
    role: "Хранительница святилища",
    about: "Старая, зрячая, пахнет воском и укропом. Знала Сержа живым.",
  },
  marfa: {
    name: "Марфа",
    role: "Хозяйка «Сухой ложки»",
    about: "Кормит Солницу и собирает правду сдачей. Теплая, пока её не обманывают дважды.",
  },
  bram: {
    name: "Брам",
    role: "Кузнец",
    about: "Лесной дворф, который разговаривает с металлом охотнее, чем с заказчиками.",
  },
  elder: {
    name: "Староста Ивен",
    role: "Голос Солницы",
    about: "Хочет, чтобы деревня дожила до жатвы обычного хлеба, без богов в закромах.",
  },
  serge: {
    name: "Серж",
    role: "Страж Печати",
    about: "Умер на Вейрской заставе, вложив тебе в ладонь чужое сердце мира.",
  },
};

export function computeSpellMax(classId: ClassId, race: RaceId, level: number): number {
  if (classId === "sorcerer") return 3 + Math.floor((level - 1) / 2);
  if (race === "elf") return 1;
  return 0;
}

export function armorClass(hero: Hero): number {
  const dex = mod(hero.stats.dex);
  let base = 10 + dex;
  if (hero.armor === "heavy") base = 16;
  else if (hero.armor === "medium") base = 14 + Math.min(dex, 2);
  else if (hero.armor === "light") base = 12 + dex;
  else if (hero.armor === "shroud") base = 13 + Math.min(dex, 2);
  return base + hero.armorBonus;
}

export function finalStats(d: Draft): Stats | null {
  if (!d.race || !d.classId || !d.body) return null;
  const stats = {} as Stats;
  for (const key of STAT_KEYS) {
    const base = d.assigned[key];
    if (base == null) return null;
    stats[key] =
      base +
      (RACES[d.race].mods[key] ?? 0) +
      (CLASSES[d.classId].mods[key] ?? 0) +
      (BODIES[d.body].mods[key] ?? 0);
  }
  return stats;
}

export function createHero(d: Draft): Hero {
  const stats = finalStats(d);
  if (!stats || !d.gender || !d.body || !d.race || !d.classId) {
    throw new Error("Герой собран не до конца");
  }
  const cls = CLASSES[d.classId];
  const maxHp = Math.max(1, cls.hp + mod(stats.con));
  const spellMax = computeSpellMax(d.classId, d.race, 1);
  return {
    name: d.name.trim(),
    gender: d.gender,
    body: d.body,
    race: d.race,
    classId: d.classId,
    stats,
    level: 1,
    xp: 0,
    hp: maxHp,
    maxHp,
    gold: cls.gold,
    weapon: cls.weapon,
    armor: cls.armor,
    armorBonus: 0,
    skills: [cls.skill],
    inventory: { [cls.weapon]: 1, potion: 1 },
    resources: {
      breath: d.race === "dragon",
      spell: spellMax,
      spellMax,
      grit: d.race === "human",
      classPower: true,
    },
  };
}

export function validName(name: string): boolean {
  const t = name.trim();
  return t.length >= 2 && t.length <= 18 && /^[\p{L}][\p{L}\s'’-]*$/u.test(t);
}

export function who(hero: Hero): string {
  if (hero.gender === "f") return "путница";
  if (hero.gender === "m") return "путник";
  return hero.name;
}

export function skillById(id: string): SkillDef | undefined {
  return SKILLS.find((s) => s.id === id);
}
