import { ENEMIES } from "./content";
import { SCENES } from "./world";

export function validateWorld(): string[] {
  const ids = new Set<string>();
  const problems: string[] = [];
  for (const scene of SCENES) {
    if (ids.has(scene.id)) problems.push(`duplicate scene ${scene.id}`);
    ids.add(scene.id);
    const choiceIds = new Set<string>();
    for (const choice of scene.choices) {
      if (choiceIds.has(choice.id)) problems.push(`duplicate choice ${scene.id}/${choice.id}`);
      choiceIds.add(choice.id);
      if (choice.check && !choice.fail) problems.push(`${scene.id}/${choice.id} check without fail`);
      for (const outcome of [choice.success, choice.fail]) {
        if (!outcome?.next) continue;
        const next = outcome.next;
        if (next.startsWith("combat:")) {
          const enemy = next.slice(7);
          if (!ENEMIES[enemy]) problems.push(`${scene.id}/${choice.id} bad enemy ${enemy}`);
        } else if (next === "return_hub" || next === "replay_ending") {
          continue;
        } else if (!ids.has(next) && !SCENES.some((item) => item.id === next)) {
          problems.push(`${scene.id}/${choice.id} -> ${next}`);
        }
      }
    }
  }
  for (const enemy of Object.values(ENEMIES)) {
    for (const key of [enemy.victory, enemy.defeat, enemy.flee] as const) {
      if (key === "return_hub") continue;
      if (!SCENES.some((scene) => scene.id === key)) problems.push(`enemy ${enemy.id} -> ${key}`);
    }
  }
  return problems;
}
