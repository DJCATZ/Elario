export type StatKey = "str" | "dex" | "con" | "int" | "wis" | "cha";
export type Stats = Record<StatKey, number>;

export type RaceId = "human" | "elf" | "dwarf" | "dragon" | "tiefling";
export type ClassId = "warrior" | "sorcerer" | "rogue" | "cleric" | "ranger";
export type GenderId = "m" | "f" | "x";
export type BodyId = "frail" | "athletic" | "massive" | "soft";
export type ArmorId = "heavy" | "medium" | "light" | "shroud" | "none";
export type NpcId =
  | "lira"
  | "kael"
  | "issa"
  | "nessa"
  | "marfa"
  | "bram"
  | "elder"
  | "serge";
export type ArtId = "ruin" | "village" | "forest" | "spire";

export type SkillId =
  | "athletics"
  | "stealth"
  | "lock"
  | "persuade"
  | "arcana"
  | "insight"
  | "survival"
  | "medicine";

export type Draft = {
  name: string;
  gender: GenderId | null;
  body: BodyId | null;
  race: RaceId | null;
  classId: ClassId | null;
  pool: number[];
  assigned: Partial<Stats>;
  picked: number | null;
};

export type Resources = {
  breath: boolean;
  spell: number;
  spellMax: number;
  grit: boolean;
  classPower: boolean;
};

export type Hero = {
  name: string;
  gender: GenderId;
  body: BodyId;
  race: RaceId;
  classId: ClassId;
  stats: Stats;
  level: number;
  xp: number;
  hp: number;
  maxHp: number;
  gold: number;
  weapon: string;
  armor: ArmorId;
  armorBonus: number;
  skills: SkillId[];
  inventory: Record<string, number>;
  resources: Resources;
};

export type NpcState = {
  rel: number;
  met: boolean;
  inParty: boolean;
  romance: boolean;
};

export type Quest = {
  id: string;
  title: string;
  stage: string;
  done: boolean;
};

export type RollView = {
  label: string;
  stat: StatKey;
  d20: number;
  d20b?: number;
  mod: number;
  total: number;
  dc: number;
  success: boolean;
  crit: boolean;
  fumble: boolean;
  grit?: boolean;
};

export type LogEntry = {
  id: string;
  kind: "narration" | "system" | "roll" | "combat" | "speech";
  text: string;
  roll?: RollView;
};

export type CombatState = {
  enemyId: string;
  hp: number;
  max: number;
  round: number;
  enemyMissed: boolean;
  defending: boolean;
  ambushed: boolean;
};

export type Save = {
  version: 1;
  phase: "title" | "create" | "play";
  createStep: number;
  draft: Draft;
  hero: Hero | null;
  sceneId: string;
  location: string;
  flags: Record<string, boolean>;
  quests: Quest[];
  npcs: Record<NpcId, NpcState>;
  corruption: number;
  log: LogEntry[];
  combat: CombatState | null;
  pendingLevel: number;
  sound: boolean;
};

export type Effect =
  | { op: "hp"; n: number }
  | { op: "gold"; n: number }
  | { op: "item"; id: string; n?: number }
  | { op: "take"; id: string; n?: number }
  | { op: "flag"; id: string }
  | { op: "unflag"; id: string }
  | { op: "rel"; npc: NpcId; n: number }
  | { op: "party"; npc: NpcId; in: boolean }
  | { op: "met"; npc: NpcId }
  | { op: "romance"; npc: NpcId }
  | { op: "quest"; id: string; title: string; stage: string; done?: boolean }
  | { op: "corrupt"; n: number }
  | { op: "rest" }
  | { op: "shortRest" }
  | { op: "equip"; id: string }
  | { op: "armorBonus" }
  | { op: "healFull" }
  | { op: "spendBreath" }
  | { op: "sellJunk" };

export type CheckSpec = {
  stat: StatKey;
  dc: number | ((s: Save) => number);
  skill?: SkillId;
  dark?: boolean;
  lock?: boolean;
  survival?: boolean;
  intimidate?: boolean;
  arcana?: boolean;
  advantage?: boolean;
};

export type Outcome = {
  text?: string;
  effects?: Effect[];
  next?: string;
  xp?: number;
};

export type Req = {
  flag?: string;
  notFlag?: string;
  anyFlag?: string[];
  item?: string;
  notItem?: string;
  gold?: number;
  classId?: ClassId;
  race?: RaceId;
  party?: NpcId;
  notParty?: NpcId;
  met?: NpcId;
  rel?: { npc: NpcId; min: number };
  relMax?: { npc: NpcId; max: number };
  stat?: StatKey;
  min?: number;
  skill?: SkillId;
  hasParty?: boolean;
  allParty?: NpcId[];
};

export type Choice = {
  id: string;
  label: string;
  tags?: string[];
  requires?: Req;
  cost?: number;
  check?: CheckSpec;
  success: Outcome;
  fail?: Outcome;
};

export type Scene = {
  id: string;
  location: string;
  art: ArtId;
  body: string[];
  extra?: (s: Save) => string[];
  choices: Choice[];
};

export type CombatAction =
  | "attack"
  | "power"
  | "smite"
  | "heal"
  | "spell"
  | "breath"
  | "seed"
  | "potion"
  | "defend"
  | "flee";
