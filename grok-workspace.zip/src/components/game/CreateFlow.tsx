import {
  BODIES,
  CLASSES,
  GENDERS,
  RACES,
  STAT_FULL,
  STAT_KEYS,
  STAT_SHORT,
  armorClass,
  createHero,
  finalStats,
  mod,
  skillById,
  validName,
} from "@/game/content";
import { signed } from "@/game/presentation";
import { useGame } from "@/game/store";
import type { BodyId, ClassId, GenderId, RaceId, StatKey } from "@/game/types";

const STEPS = ["Имя", "Пол", "Стать", "Раса", "Путь", "Дары", "Клятва"];

export function CreateFlow() {
  const draft = useGame((s) => s.save.draft);
  const step = useGame((s) => s.save.createStep);
  const patchDraft = useGame((s) => s.patchDraft);
  const setStep = useGame((s) => s.setStep);
  const toTitle = useGame((s) => s.toTitle);
  const begin = useGame((s) => s.begin);
  const preview = finalStats(draft);

  const canNext =
    (step === 0 && validName(draft.name)) ||
    (step === 1 && !!draft.gender) ||
    (step === 2 && !!draft.body) ||
    (step === 3 && !!draft.race) ||
    (step === 4 && !!draft.classId) ||
    (step === 5 && !!preview) ||
    step === 6;

  return (
    <main className="shell">
      <header className="hud">
        <div className="hud-top">
          <button type="button" className="btn btn-ghost tiny-btn" onClick={() => (step === 0 ? toTitle() : setStep(step - 1))}>
            Назад
          </button>
          <p className="eyebrow">
            {step + 1} / {STEPS.length} · {STEPS[step]}
          </p>
        </div>
        <div className="dots" aria-hidden="true">
          {STEPS.map((label, index) => (
            <span key={label} className={index === step ? "on" : index < step ? "done" : ""} />
          ))}
        </div>
      </header>
      <div className="scroll create-scroll">
        {step === 0 && (
          <section>
            <h1>Как тебя звать на тракте</h1>
            <p className="muted">Имя услышит и умирающий страж, и семя. Короткое, настоящее.</p>
            <input
              className="field"
              value={draft.name}
              maxLength={18}
              autoFocus
              placeholder="Например, Мира"
              onChange={(event) => patchDraft({ name: event.target.value })}
            />
          </section>
        )}
        {step === 1 && (
          <section>
            <h1>Пол</h1>
            <p className="muted">На речи мира, не на твою свободу. Близость потом не спросит разрешения у графы.</p>
            <div className="grid-cards">
              {GENDERS.map((gender) => (
                <button
                  key={gender.id}
                  type="button"
                  className={draft.gender === gender.id ? "card on" : "card"}
                  onClick={() => patchDraft({ gender: gender.id as GenderId })}
                >
                  <strong>{gender.name}</strong>
                  <p>{gender.hint}</p>
                </button>
              ))}
            </div>
          </section>
        )}
        {step === 2 && (
          <section>
            <h1>Телосложение</h1>
            <p className="muted">Как ты занимаешь дверной проём и чужой взгляд. Это про стать, не про постель.</p>
            <div className="grid-cards">
              {(Object.values(BODIES)).map((body) => (
                <button
                  key={body.id}
                  type="button"
                  className={draft.body === body.id ? "card on" : "card"}
                  onClick={() => patchDraft({ body: body.id as BodyId })}
                >
                  <strong>{body.name}</strong>
                  <em>{body.bonus}</em>
                  <p>{body.phrase}</p>
                </button>
              ))}
            </div>
          </section>
        )}
        {step === 3 && (
          <section>
            <h1>Кровь</h1>
            <div className="grid-cards">
              {Object.values(RACES).map((race) => (
                <button
                  key={race.id}
                  type="button"
                  className={draft.race === race.id ? "card on" : "card"}
                  onClick={() => patchDraft({ race: race.id as RaceId })}
                >
                  <strong>{race.name}</strong>
                  <em>{race.bonus}</em>
                  <p>{race.trait}</p>
                </button>
              ))}
            </div>
          </section>
        )}
        {step === 4 && (
          <section>
            <h1>Путь</h1>
            <div className="grid-cards">
              {Object.values(CLASSES).map((cls) => (
                <button
                  key={cls.id}
                  type="button"
                  className={draft.classId === cls.id ? "card on" : "card"}
                  onClick={() => patchDraft({ classId: cls.id as ClassId })}
                >
                  <strong>{cls.name}</strong>
                  <em>{cls.bonus}</em>
                  <p>{cls.trait}</p>
                </button>
              ))}
            </div>
          </section>
        )}
        {step === 5 && (
          <section>
            <h1>Шесть даров</h1>
            <p className="muted">
              Разложи 15, 14, 13, 12, 10 и 8. Раса, путь и стать прибавятся сами.
              {draft.picked != null ? ` Выбрано ${draft.picked} — коснись характеристики.` : " Коснись числа, потом строки."}
            </p>
            <div className="chips">
              {draft.pool.map((value, index) => (
                <button
                  key={`${value}-${index}`}
                  type="button"
                  className={draft.picked === value ? "chip on" : "chip"}
                  onClick={() => patchDraft({ picked: draft.picked === value ? null : value })}
                >
                  {value}
                </button>
              ))}
            </div>
            <div className="stat-list">
              {STAT_KEYS.map((key) => {
                const base = draft.assigned[key];
                const total = preview?.[key];
                return (
                  <button key={key} type="button" className="stat-row" onClick={() => assign(key)}>
                    <span>{STAT_SHORT[key]}</span>
                    <strong>{STAT_FULL[key]}</strong>
                    <em>{base ?? "—"}</em>
                    <span className="gold">{total != null ? `${total} (${signed(mod(total))})` : ""}</span>
                  </button>
                );
              })}
            </div>
          </section>
        )}
        {step === 6 && preview && draft.race && draft.classId && draft.body && draft.gender && (
          <Confirm preview={preview} />
        )}
      </div>
      <footer className="dock slim">
        <button
          type="button"
          className="btn btn-primary"
          disabled={!canNext}
          onClick={() => (step === 6 ? begin() : setStep(step + 1))}
        >
          {step === 6 ? "Войти в Элерию" : "Дальше"}
        </button>
      </footer>
    </main>
  );

  function assign(key: StatKey) {
    const assigned = { ...draft.assigned };
    const pool = [...draft.pool];
    if (draft.picked == null) {
      const current = assigned[key];
      if (current == null) return;
      delete assigned[key];
      pool.push(current);
      pool.sort((a, b) => b - a);
      patchDraft({ assigned, pool, picked: null });
      return;
    }
    const index = pool.indexOf(draft.picked);
    if (index < 0) return;
    pool.splice(index, 1);
    if (assigned[key] != null) pool.push(assigned[key]!);
    assigned[key] = draft.picked;
    pool.sort((a, b) => b - a);
    patchDraft({ assigned, pool, picked: null });
  }
}

function Confirm({ preview }: { preview: Record<StatKey, number> }) {
  const draft = useGame((s) => s.save.draft);
  const hero = createHero({ ...draft, name: draft.name.trim() || "Путник" });
  const race = RACES[hero.race];
  const cls = CLASSES[hero.classId];
  const skill = skillById(cls.skill);
  return (
    <section>
      <h1>{hero.name}</h1>
      <p className="lede">
        {race.name}, {cls.name.toLowerCase()}. {BODIES[hero.body].phrase}. На рассвете ты очнёшься в пепле Вейрской заставы — и семя уже будет знать, как тебя зовут.
      </p>
      <ul className="plain">
        <li>Здоровье {hero.hp} · защита {armorClass(hero)} · золото {hero.gold}</li>
        <li>Навык: {skill?.name}. {cls.trait}</li>
        <li>{race.trait}</li>
      </ul>
      <div className="stat-list readonly">
        {STAT_KEYS.map((key) => (
          <div key={key} className="stat-row">
            <span>{STAT_SHORT[key]}</span>
            <strong>{STAT_FULL[key]}</strong>
            <em>{preview[key]}</em>
            <span className="gold">{signed(mod(preview[key]))}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
