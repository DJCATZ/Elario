import {
  CLASSES,
  ITEMS,
  NPCS,
  RACES,
  SKILLS,
  STAT_FULL,
  STAT_KEYS,
  STAT_SHORT,
  armorClass,
  mod,
  skillById,
} from "@/game/content";
import { relLabel, signed } from "@/game/presentation";
import { useGame, type SheetId } from "@/game/store";
import type { NpcId } from "@/game/types";
import { BookOpen, ScrollText, Shield, Sparkles, Swords, X } from "lucide-react";

const TABS: { id: Exclude<SheetId, null>; label: string; icon: typeof Shield }[] = [
  { id: "hero", label: "Герой", icon: Shield },
  { id: "bag", label: "Сумка", icon: Swords },
  { id: "people", label: "Люди", icon: Sparkles },
  { id: "quests", label: "Нити", icon: ScrollText },
  { id: "help", label: "Кости", icon: BookOpen },
];

export function Sheets() {
  const sheet = useGame((s) => s.sheet);
  const setSheet = useGame((s) => s.setSheet);
  if (!sheet) return null;
  return (
    <div className="sheet" role="dialog" aria-label="Листы героя">
      <header className="hud-top">
        <p className="eyebrow">Книга партии</p>
        <button type="button" className="icon-btn" onClick={() => setSheet(null)} aria-label="Закрыть">
          <X />
        </button>
      </header>
      <div className="sheet-tabs">
        {TABS.map((tab) => (
          <button key={tab.id} type="button" className={sheet === tab.id ? "on" : ""} onClick={() => setSheet(tab.id)}>
            {tab.label}
          </button>
        ))}
      </div>
      <div className="scroll sheet-body">
        {sheet === "hero" && <HeroSheet />}
        {sheet === "bag" && <BagSheet />}
        {sheet === "people" && <PeopleSheet />}
        {sheet === "quests" && <QuestSheet />}
        {sheet === "help" && <HelpSheet />}
      </div>
    </div>
  );
}

function HeroSheet() {
  const hero = useGame((s) => s.save.hero);
  const corruption = useGame((s) => s.save.corruption);
  if (!hero) return null;
  const race = RACES[hero.race];
  const cls = CLASSES[hero.classId];
  return (
    <section>
      <h2>
        {hero.name}
      </h2>
      <p className="muted">
        {race.name} · {cls.name} · защита {armorClass(hero)}
      </p>
      <p>{race.trait}</p>
      <p>{cls.trait}</p>
      <div className="stat-list readonly">
        {STAT_KEYS.map((key) => (
          <div key={key} className="stat-row">
            <span>{STAT_SHORT[key]}</span>
            <strong>{STAT_FULL[key]}</strong>
            <em>{hero.stats[key]}</em>
            <span className="gold">{signed(mod(hero.stats[key]))}</span>
          </div>
        ))}
      </div>
      <h3>Навыки</h3>
      <ul className="plain">
        {hero.skills.map((id) => {
          const skill = skillById(id);
          return (
            <li key={id}>
              {skill?.name} — {skill?.blurb}
            </li>
          );
        })}
      </ul>
      {corruption > 0 && (
        <p className="danger">Шёпот семени: {corruption}/100. Чем выше, тем громче Жатва внутри.</p>
      )}
    </section>
  );
}

function BagSheet() {
  const save = useGame((s) => s.save);
  const equip = useGame((s) => s.equip);
  const drink = useGame((s) => s.drink);
  const hero = save.hero;
  if (!hero) return null;
  const entries = Object.entries(hero.inventory).filter(([, n]) => n > 0);
  if (!entries.length) return <p>Сумка пуста, если не считать пепла.</p>;
  return (
    <ul className="plain items">
      {entries.map(([id, count]) => {
        const item = ITEMS[id];
        if (!item) return null;
        return (
          <li key={id}>
            <strong>
              {item.name}
              {count > 1 ? ` ×${count}` : ""}
              {hero.weapon === id ? " · в руке" : ""}
            </strong>
            <p>{item.desc}</p>
            <div className="row">
              {item.weapon && hero.weapon !== id && (
                <button type="button" className="btn btn-ghost tiny-btn" onClick={() => equip(id)}>
                  Взять в руку
                </button>
              )}
              {id === "potion" && !save.combat && (
                <button type="button" className="btn btn-ghost tiny-btn" onClick={drink}>
                  Выпить
                </button>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function PeopleSheet() {
  const npcs = useGame((s) => s.save.npcs);
  const met = (Object.keys(npcs) as NpcId[]).filter((id) => npcs[id].met);
  if (!met.length) return <p>Пока только пепел и твоё имя.</p>;
  return (
    <ul className="plain items">
      {met.map((id) => {
        const npc = npcs[id];
        const meta = NPCS[id];
        const width = `${((npc.rel + 100) / 200) * 100}%`;
        return (
          <li key={id}>
            <strong>{meta.name}</strong>
            <p className="muted">
              {meta.role}
              {npc.inParty ? " · в пути" : ""}
              {npc.romance ? " · близко" : ""}
            </p>
            <p>{meta.about}</p>
            <div className="rel" aria-label={`Отношения ${npc.rel}`}>
              <span style={{ width }} />
            </div>
            <p className="tiny">
              {relLabel(npc.rel)} · {npc.rel}/100
            </p>
          </li>
        );
      })}
    </ul>
  );
}

function QuestSheet() {
  const quests = useGame((s) => s.save.quests);
  if (!quests.length) return <p>Нити ещё не названы. Доживи до первого обещания.</p>;
  return (
    <ul className="plain items">
      {quests.map((quest) => (
        <li key={quest.id}>
          <strong>
            {quest.title}
            {quest.done ? " · оборвана" : ""}
          </strong>
          <p>{quest.stage}</p>
        </li>
      ))}
    </ul>
  );
}

function HelpSheet() {
  return (
    <section className="prose help">
      <h2>Как решают кости</h2>
      <p>Сложный шаг — это d20 плюс модификатор характеристики против класса сложности.</p>
      <p>[Проверка Харизмы: d20(14) + 3 = 17 vs КС 15 — Успех!]</p>
      <p>Естественная 20 — триумф, даже если числа не хватало. Естественная 1 — беда, даже если числа хватало. Если в скобках две кости, первая пошла в зачёт: большая при преимуществе, меньшая когда ты в защите.</p>
      <p>Опыт капает за бои, удачные проверки и узлы квеста. На новом уровне растёт здоровье, и ты берёшь либо +1 к характеристике, либо навык.</p>
      <p>Отношения от −100 до +100. Любой, кого встретишь, может стать спутником, врагом или тем, с кем делишь ночь без отчёта.</p>
      <p>Свой вариант ответа понимает речь: «осмотреться», «скрыться», «уговорить», «в лес». Если затея не из ясных шагов, кость всё равно бросится — но большая тропа не свернёт от одной красивой фразы.</p>
      <ul className="plain">
        {SKILLS.map((skill) => (
          <li key={skill.id}>
            {skill.name}: {skill.blurb}
          </li>
        ))}
      </ul>
    </section>
  );
}
