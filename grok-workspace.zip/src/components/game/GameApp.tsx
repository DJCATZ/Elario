import { useGame } from "@/game/store";
import { useEffect, useState } from "react";
import { CreateFlow } from "./CreateFlow";
import { PlayView } from "./PlayView";

export function GameApp() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        await useGame.persist.rehydrate();
      } catch {
        /* повреждённое сохранение не должно гасить превью */
      }
      if (alive) setReady(true);
    })();
    return () => {
      alive = false;
    };
  }, []);
  if (!ready) return <Splash />;
  return <Shell />;
}

function Shell() {
  const phase = useGame((s) => s.save.phase);
  const hero = useGame((s) => s.save.hero);
  if (phase === "create") return <CreateFlow />;
  if (phase === "play" && hero) return <PlayView />;
  return <Title />;
}

function Splash() {
  return (
    <main className="shell splash">
      <p className="eyebrow">Элерия</p>
      <h1>Тайна Проклятого Семени</h1>
    </main>
  );
}

function Title() {
  const save = useGame((s) => s.save);
  const toCreate = useGame((s) => s.toCreate);
  const continueGame = useGame((s) => s.continueGame);
  const canContinue = !!save.hero && save.log.length > 0;
  return (
    <main className="shell">
      <div className="title-hero art-ruin">
        <img src="/art/ruin.jpg" alt="" onError={(event) => (event.currentTarget.hidden = true)} />
        <div className="banner-scrim" />
      </div>
      <div className="scroll title-copy">
        <p className="eyebrow">После Падения Богов</p>
        <h1>Элерия</h1>
        <p className="subtitle">Тайна Проклятого Семени</p>
        <div className="prose lore">
          <p>
            Элерия пережила Падение. Боги не ушли в миф — они раскололись. Осколки, которые жрецы называют Семями, до сих пор лежат в руинах и переписывают плоть, землю и память.
          </p>
          <p>
            Магия здесь — кровь предков, смешанная с их машинами: латунные жилы под корнями, стеклянные сердца в башнях, карты неба, которые всё ещё дышат.
          </p>
          <p>
            Тебя застала буря на Тракте Пепла. Караван молчит. В руке умирающего стража стучит чёрное семя, и оно уже знает, как тебя зовут.
          </p>
          <p>
            Это история о выживании и о том, кого ты подпустишь близко. Кости d20 решают, когда цена высока. Можно сжечь Жатву, посадить её, стать ею — или рассеять, чтобы мир дышал сам.
          </p>
        </div>
        <div className="actions">
          {canContinue && (
            <button type="button" className="btn btn-primary" onClick={continueGame}>
              Продолжить путь
            </button>
          )}
          <button type="button" className="btn btn-ghost" onClick={toCreate}>
            {canContinue ? "Новый герой" : "Создать героя"}
          </button>
        </div>
        <p className="tiny">История для телефона. Партия хранится на этом устройстве сама.</p>
      </div>
    </main>
  );
}
