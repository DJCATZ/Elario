import { CLASSES, SKILLS, STAT_FULL, STAT_KEYS } from "@/game/content";
import { canSneak, visibleChoices } from "@/game/engine";
import { statusText, xpNeed } from "@/game/presentation";
import { getScene } from "@/game/world";
import { useGame } from "@/game/store";
import type { CombatAction, StatKey } from "@/game/types";
import { BookOpen, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Sheets } from "./Sheets";

const ART: Record<string, string> = {
  ruin: "/art/ruin.jpg",
  village: "/art/village.jpg",
  forest: "/art/forest.jpg",
  spire: "/art/spire.jpg",
};

export function PlayView() {
  const save = useGame((s) => s.save);
  const choose = useGame((s) => s.choose);
  const freeText = useGame((s) => s.freeText);
  const combatAct = useGame((s) => s.combat);
  const levelPick = useGame((s) => s.levelPick);
  const setSheet = useGame((s) => s.setSheet);
  const toggleSound = useGame((s) => s.toggleSound);
  const setAskNew = useGame((s) => s.setAskNew);
  const askNew = useGame((s) => s.askNew);
  const reset = useGame((s) => s.reset);
  const sheet = useGame((s) => s.sheet);
  const logRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const [line, setLine] = useState("");
  const hero = save.hero!;
  const scene = getScene(save.sceneId);
  const choices = save.combat || save.pendingLevel > 0 ? [] : visibleChoices(save);
  const showLevel = save.pendingLevel > 0 && !save.combat;

  useEffect(() => {
    const last = save.log[save.log.length - 1];
    if (last?.kind === "roll" || last?.kind === "combat") blip(save.sound, last.kind === "roll" ? "roll" : "hit");
  }, [save.log, save.sound]);

  useEffect(() => {
    const el = logRef.current;
    if (!el || !stick.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: prefersReduced() ? "auto" : "smooth" });
  }, [save.log.length, save.combat?.hp, save.sceneId]);

  const pct = Math.max(0, Math.min(100, (hero.hp / hero.maxHp) * 100));
  const art = ART[scene?.art ?? "village"] ?? ART.village;

  return (
    <main className="shell">
      <header className="hud">
        <div className="hud-top">
          <div>
            <p className="eyebrow">Элерия</p>
            <strong className="loc">{save.location}</strong>
          </div>
          <div className="row">
            <button type="button" className="icon-btn" onClick={toggleSound} aria-label={save.sound ? "Выключить звук" : "Включить звук"}>
              {save.sound ? <Volume2 /> : <VolumeX />}
            </button>
            <button type="button" className="icon-btn" onClick={() => setSheet(sheet ? null : "hero")} aria-label="Книга партии">
              <BookOpen />
            </button>
          </div>
        </div>
        <div className="hp-row">
          <div className="hp" aria-label={`Здоровье ${hero.hp} из ${hero.maxHp}`}>
            <span style={{ width: `${pct}%` }} />
          </div>
          <span className="tiny">
            {hero.hp}/{hero.maxHp}
          </span>
          <span className="tiny">
            Ур. {hero.level}
          </span>
          <span className="tiny gold">{hero.gold} зл.</span>
        </div>
        {save.corruption > 0 && (
          <p className="tiny danger">Шёпот семени {save.corruption}/100</p>
        )}
      </header>
      <div className={`banner art-${scene?.art ?? "village"}`}>
        <img src={art} alt="" onError={(event) => (event.currentTarget.hidden = true)} />
        <div className="banner-scrim" />
      </div>
      <div
        className="scroll log"
        ref={logRef}
        onScroll={(event) => {
          const el = event.currentTarget;
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
        }}
      >
        {save.log.map((entry, index) => (
          <article
            key={entry.id}
            className={`entry ${entry.kind}${entry.roll ? (entry.roll.success ? " ok" : " bad") : ""}`}
            aria-live={index === save.log.length - 1 ? "polite" : undefined}
          >
            {entry.text}
          </article>
        ))}
      </div>
      <footer className="dock">
        <pre className="status">{statusText(save)}</pre>
        {save.combat && (
          <CombatBar
            name={save.combat.enemyId}
            hp={save.combat.hp}
            max={save.combat.max}
            onAct={combatAct}
          />
        )}
        {!save.combat && !showLevel && (
          <div className="choices">
            {choices.map((choice, index) => (
              <button key={choice.id} type="button" className="choice" onClick={() => choose(choice.id)}>
                <span className="num">{index + 1}</span>
                <span>{choice.label}</span>
              </button>
            ))}
            <form
              className="free"
              onSubmit={(event) => {
                event.preventDefault();
                const value = line.trim();
                if (!value) return;
                freeText(value);
                setLine("");
                stick.current = true;
              }}
            >
              <span className="num">{choices.length + 1}</span>
              <input
                value={line}
                onChange={(event) => setLine(event.target.value)}
                placeholder="Свой вариант ответа"
                aria-label="Свой вариант ответа"
                maxLength={180}
              />
              <button type="submit" className="btn btn-primary tiny-btn">
                Решить
              </button>
            </form>
          </div>
        )}
        <button type="button" className="text-btn" onClick={() => setAskNew(true)}>
          Начать заново
        </button>
      </footer>
      {showLevel && <LevelModal onPick={levelPick} level={hero.level} stats={hero.stats} skills={hero.skills} />}
      {sheet && <Sheets />}
      {askNew && (
        <div className="modal">
          <div className="modal-card">
            <h2>Сжечь эту партию?</h2>
            <p>Текущая история сотрётся с этого устройства.</p>
            <div className="row">
              <button type="button" className="btn btn-ghost" onClick={() => setAskNew(false)}>
                Остаться
              </button>
              <button type="button" className="btn btn-danger" onClick={reset}>
                Новая история
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function CombatBar({
  name,
  hp,
  max,
  onAct,
}: {
  name: string;
  hp: number;
  max: number;
  onAct: (action: CombatAction) => void;
}) {
  const save = useGame((s) => s.save);
  const hero = save.hero!;
  const combat = save.combat!;
  const width = `${Math.max(0, Math.min(100, (hp / max) * 100))}%`;
  const enemyName =
    name === "wolves"
      ? "Стая"
      : name === "scouts"
        ? "Дозор"
        : name === "construct"
          ? "Архивариус"
          : name === "guardian"
            ? "Страж"
            : name === "issa"
              ? "Исса"
              : "Шакал";
  const sneak = canSneak(hero, combat);
  return (
    <div className="combat-box">
      <div className="hp-row">
        <strong>{enemyName}</strong>
        <div className="hp enemy">
          <span style={{ width }} />
        </div>
        <span className="tiny">
          {hp}/{max}
        </span>
      </div>
      <div className="choices">
        <button type="button" className="choice" onClick={() => onAct("attack")}>
          <span className="num">1</span>
          <span>{sneak ? "Удар из тени" : "Атака"}</span>
        </button>
        {hero.classId === "warrior" && (
          <button type="button" className="choice" disabled={!hero.resources.classPower} onClick={() => onAct("power")}>
            Рассекающий удар
          </button>
        )}
        {hero.classId === "ranger" && (
          <button type="button" className="choice" disabled={!hero.resources.classPower} onClick={() => onAct("power")}>
            Меткий выстрел
          </button>
        )}
        {hero.classId === "cleric" && (
          <>
            <button type="button" className="choice" disabled={!hero.resources.classPower} onClick={() => onAct("smite")}>
              Кара печати
            </button>
            <button type="button" className="choice" disabled={!hero.resources.classPower} onClick={() => onAct("heal")}>
              Свет лечения
            </button>
          </>
        )}
        {hero.resources.spellMax > 0 && (
          <button type="button" className="choice" disabled={hero.resources.spell <= 0} onClick={() => onAct("spell")}>
            Искра Архива ({hero.resources.spell})
          </button>
        )}
        {hero.race === "dragon" && (
          <button type="button" className="choice" disabled={!hero.resources.breath} onClick={() => onAct("breath")}>
            Дыхание пепла
          </button>
        )}
        {save.flags.hasSeed && (
          <button type="button" className="choice" onClick={() => onAct("seed")}>
            Шёпот семени
          </button>
        )}
        {(hero.inventory.potion ?? 0) > 0 && (
          <button type="button" className="choice" onClick={() => onAct("potion")}>
            Зелье ({hero.inventory.potion})
          </button>
        )}
        <button type="button" className="choice" onClick={() => onAct("defend")}>
          Закрыться
        </button>
        <button type="button" className="choice" onClick={() => onAct("flee")}>
          Отступить
        </button>
      </div>
    </div>
  );
}

function LevelModal({
  level,
  stats,
  skills,
  onPick,
}: {
  level: number;
  stats: Record<StatKey, number>;
  skills: string[];
  onPick: (kind: "stat" | "skill", id: string) => void;
}) {
  const fresh = SKILLS.filter((skill) => !skills.includes(skill.id));
  return (
    <div className="modal">
      <div className="modal-card scroll">
        <p className="eyebrow">Уровень {level}</p>
        <h2>Выбери дар</h2>
        <p className="muted">Одно: характеристика или новый навык. Нужно ещё {xpNeed(level)} опыта до следующего.</p>
        <div className="grid-cards">
          {STAT_KEYS.map((key) => (
            <button key={key} type="button" className="card" disabled={stats[key] >= 20} onClick={() => onPick("stat", key)}>
              <strong>+1 {STAT_FULL[key]}</strong>
              <p>Сейчас {stats[key]}</p>
            </button>
          ))}
          {fresh.map((skill) => (
            <button key={skill.id} type="button" className="card" onClick={() => onPick("skill", skill.id)}>
              <strong>{skill.name}</strong>
              <p>{skill.blurb}</p>
            </button>
          ))}
        </div>
        <p className="tiny">Путь: {CLASSES[useGame.getState().save.hero!.classId].name}. Дар не отменить.</p>
      </div>
    </div>
  );
}

function prefersReduced(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

let audio: AudioContext | null = null;
function blip(enabled: boolean, kind: "roll" | "hit") {
  if (!enabled || typeof window === "undefined") return;
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audio ??= new Ctx();
    if (audio.state === "suspended") void audio.resume();
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = kind === "hit" ? "triangle" : "sine";
    osc.frequency.value = kind === "roll" ? 540 : 150;
    gain.gain.value = 0.03;
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.12);
    osc.stop(audio.currentTime + 0.13);
  } catch {
    /* звук — роскошь, не условие игры */
  }
}
